#!/usr/bin/env python
from .schematic_blocks_pluging_action import SchematicBlocksPluging
SchematicBlocksPluging().register() # Instantiate and register to Pcbnew